<?php
//Creamos la funcion para abrir la conexion con la base de datos
function OpenCon()
 {
 $dbhost = "localhost:3308";
 $dbuser = "root";
 $dbpass = "root";
 $db = "le'soft";


 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);

 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>