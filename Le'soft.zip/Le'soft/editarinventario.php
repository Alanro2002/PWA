<?php 
include "config.php";
$conn= OpenCon();

$id = $_GET['id'];

$sql = mysqli_query($conn,"SELECT * FROM inventario WHERE id_codigo='$id'"); 

$fila = mysqli_fetch_array($sql); 

if(isset($_POST['Actualizar'])) 
{
    
    $Estatus=$_POST['Estatus'];
	
    $edit = mysqli_query($conn,"UPDATE inventario SET Estatus='$Estatus'  WHERE id_codigo='$id'");
	
    if($edit)
    {
        CloseCon($conn);
        header("location:mostrarinventario.php"); 
        exit;
    }
    else
    {
        echo "Error: " . $edit . "<br>" . $conn->error;
    }    	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Reservar</title>
</head>
<body>
<div class="container">
        <div class="row">

        <h1>Inventario</h1>

        </div>
        <div class="row">
        <h3>Update Data</h3>

<form method="POST">
  <input type="text" name="Estatus" value="<?php echo $fila['Estatus']; ?>"  Required>
  <input type="submit" name="Actualizar" value="Actualizar">
</form>
    
</body>
</html>