const CACHE_NAME="v1_cache_PWA";


var urlsToCache= [
    './',
    './css/style.css',
    './css/style(1).css',
    './imagienes/mex16.png',
   './imagienes/mex32.png',
   './imagienes/mex64.png',
   './imagienes/mex96.png',
   './imagienes/mex128.png',
   './imagienes/mex256.png',
   './imagienes/mex384.png',
   './imagienes/mex512.png',
   './imagienes/mex1024.png',
   './assets/',
    './assets/img/',
    './assets/js/',
    './assets/js/main.js',
    './assets/js/main(1).js',
    './assets/vendor/',
    './assets/vendor/animate.css',
    './assets/vendor/bootstrap/',
    './assets/vendor/bootstrap-icons/',
    './assets/vendor/php-email-form/',
    './assets/vendor/swiper/',
    './forms/',
    './forms/contact.php',
    './forms/contact(1).php',
    './changelog.txt',
    './config.php',
    './contact.html',
    './editarinventario.php',
    './eliminar.php',
    './english.html',
    './index.html',
    './index.php',
    './logout.php',
    './manifest.json',
    './mostrarinventario.php',
    './mostrarjuegos.php',
    './property-grid.html',
    './Readme.txt',
    './Readme(1).txt',
    './registrar.php',
    './sw.js',
    './welcome.php'
];


self.addEventListener('install' ,e => {
    e.waitUntil(
        caches.open(CACHE_NAME)
                .then(cache => {
                    return cache.addAll(urlsToCache)
                    .then(() => {
                        self.skipWaiting();
                    })
                    .catch(err => {
                        console.log('No se a cargado la cache', err);
                    })
                })
    );
});


self.addEventListener('activate', e => {
    // añadimos todos los elementos en la cache
    const cacheWhiteList = [CACHE_NAME];
    e.waitUntil(
        caches.keys()
        .then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheWhiteList.indexOf(cacheName) === -1) {
                        // borrar los elementos que ya no estén en
                        // la cache o no se necesiten
                        return caches.delete(cacheName);
                    }
                })
            );
        })
        .then(() => {
            // Activar cache en el dispositivo
            self.clients.claim();
        })
    );
});

self.addEventListener('fetch', e => {
    e.respondWith(
        caches.match(e.request)
            .then(res => {
                if (res) {
                    // devuelvo datos desde cache
                    return res;
                }
                return fetch(e.request);
            })
    );
});
