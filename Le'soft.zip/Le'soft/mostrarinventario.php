<?php
include 'config.php';

$conn = OpenCon();

$sql = 'SELECT * FROM inventario';

$resultado = $conn -> query ($sql);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar datos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <h1>Catalogo</h1>
        </div>
        <div class="row">
            <table class="table">
                <thead>
                <tr>
                <th scope="col">ID Código</th>
                <th scope="col">ID Modelo</th>
                <th scope="col">Precio</th>
                <th scope="col">Estatus</th>
                <th scope="col" colspan="2">Edición</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    if($resultado-> num_rows>0)
                    {
                        while ($fila = $resultado -> fetch_assoc()) 
                        {
                            ?>
                            <tr>
                            <td><?php echo $fila["id_codigo"];?></td>
                            <td><?php echo $fila['id_Modelo'];?></td> 
                            <td><?php echo $fila["Precio"];?></td> 
                            <td><?php echo $fila["Estatus"];?></td>
                            <td> <a href="editarinventario.php?id=<?php echo $fila['id_codigo']; ?>">Reservar</a></td>
                            </tr>
                            </tbody>
                            <?php
                        }
                    }
                    else
                    {
                        echo '0 resultados';
                    }
                    CloseCon($conn);
                    ?>
                
            </table>
        </div>
    </div>
</body>
</html>