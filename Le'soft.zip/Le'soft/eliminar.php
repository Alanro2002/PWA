<?php
include "config.php";

$conn = OpenCon();

$id=$_GET['id'];

$sql= "DELETE FROM juegos WHERE no_juego='$id'";
if ($conn->query($sql)===TRUE){
    header('Location: mostrardatos.php');
    exit;
}
else
{
    echo "No se eliminó el registro" .$conn->error;
}
CloseCon($conn);
?>