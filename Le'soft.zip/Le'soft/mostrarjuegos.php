<?php
include 'config.php';

$conn = OpenCon();

$sql = 'SELECT * FROM juegos';

$resultado = $conn -> query ($sql);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar juegos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <h1>Todos los juegos</h1>
        </div>
        <div class="row">
            <table class="table">
                <thead>
                <tr>
                <th scope="col">Numero</th>
                <th scope="col">Titulo</th>
                <th scope="col">Plataforma</th>
                <th scope="col">Soporte</th>
                <th scope="col">Año</th>

                </tr>
                </thead>
                <tbody>
                <?php
                    if($resultado-> num_rows>0)
                    {
                        while ($fila = $resultado -> fetch_assoc()) 
                        {
                            ?>
                            <tr>
                            <td><?php echo $fila['idjuegos'];?></td> 
                            <td><?php echo $fila["titulo"];?></td>
                            <td><?php echo $fila["plataforma"];?></td> 
                            <td><?php echo $fila["soporte"];?></td>
                            <td><?php echo $fila["año"];?></td> 
                            </tr>
                            </tbody>
                            <?php
                        }
                    }
                    else
                    {
                        echo '0 resultados';
                    }
                    CloseCon($conn);
                    ?>
                
            </table>
        </div>
    </div>
</body>
</html>